//
//  Task.swift
//  ToDoList
//
//  Created by Gunter on 2021/08/28.
//

import Foundation

struct Task {
  var title: String
  var done: Bool
}
