//
//  ErrorMessage.swift
//  Weather
//
//  Created by Gunter on 2021/09/17.
//

import Foundation

struct ErrorMessage: Codable {
  let message: String
}
